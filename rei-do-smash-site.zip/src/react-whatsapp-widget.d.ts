declare module 'react-whatsapp-widget';
