import { WhatsAppWidget } from 'react-whatsapp-widget';
import 'react-whatsapp-widget/dist/index.css';

const burgers = [
  {
    name: 'Clássico do Rei',
    description: 'Pão brioche, burger suculento 150g, queijo cheddar, alface, tomate e molho especial da casa.',
    price: 'R$ 50,00',
    image: '/images/burger_classic.jpeg',
  },
  {
    name: 'Bacon Real',
    description: 'Pão australiano, burger 180g, fatias generosas de bacon crocante, queijo prato e cebola caramelizada.',
    price: 'R$ 50,00',
    image: '/images/burger_bacon.webp',
  },
  {
    name: 'Duplo da Coroa',
    description: 'Pão com gergelim, dois burgers de 150g, dobro de queijo cheddar, picles e molho barbecue.',
    price: 'R$ 50,00',
    image: '/images/burger_on_plate.jpeg', // Using burger_on_plate as a double representation
  },
  {
    name: 'Fogo do Dragão',
    description: 'Pão de pimenta, burger 150g, queijo pepper jack, jalapeños, alface e maionese picante.',
    price: 'R$ 50,00',
    image: '/images/burger_flaming.png',
  },
  {
    name: 'Combo Majestade',
    description: 'Pão brioche, burger 150g, queijo, bacon, ovo, alface, tomate, acompanhado de batatas fritas crocantes.',
    price: 'R$ 50,00',
    image: '/images/burger_with_fries.jpeg',
  }
];

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between bg-gray-100 font-sans">
      {/* Header */}
      <header className="w-full bg-gradient-to-r from-yellow-400 via-red-500 to-orange-500 text-white shadow-md py-6">
        <div className="container mx-auto text-center px-4">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Rei do Smash</h1>
          <p className="mt-2 text-lg md:text-xl">O sabor que conquista!</p>
        </div>
      </header>

      {/* Sobre Nós */}
      <section id="sobre" className="container mx-auto px-4 py-12 md:py-16 text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-4">Sobre Nós</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Bem-vindo ao Rei do Smash! Nascemos da paixão por hambúrgueres de verdade, feitos com ingredientes frescos e selecionados. Cada smash burger é preparado com carinho e técnica para garantir uma explosão de sabor em cada mordida. Venha experimentar a realeza do smash!
        </p>
      </section>

      {/* Cardápio */}
      <section id="cardapio" className="w-full bg-white py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-semibold text-gray-800 text-center mb-8 md:mb-12">Nosso Cardápio Real</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {burgers.map((burger, index) => (
              <div key={index} className="bg-gray-50 rounded-lg shadow-lg overflow-hidden transform transition duration-300 hover:scale-105 flex flex-col">
                <div className="relative w-full h-60 overflow-hidden">
                   <img
                    src={burger.image}
                    alt={burger.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold text-red-600 mb-2">{burger.name}</h3>
                  <p className="text-gray-700 mb-4 flex-grow">{burger.description}</p>
                  <p className="text-2xl font-semibold text-yellow-500 mt-auto">{burger.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full py-6 text-center text-gray-500 text-sm mt-12">
        © 2025 Rei do Smash. Todos os direitos reservados.
      </footer>

      {/* WhatsApp Button - Note: Needs a phone number to be functional */}
      <WhatsAppWidget
        phoneNumber="" // Add phone number here later e.g., "5511999999999"
        companyName="Rei do Smash"
        message="Olá! Gostaria de fazer um pedido."
        sendButtonText="Enviar"
        inputPlaceHolder="Digite sua mensagem"
        chatMessage={{ text: 'Olá! Como posso ajudar?', time: 'Agora' }}
        iconSize="60"
        widgetWidth="350px"
        widgetPosition="right"
        backgroundColor="#25D366" // WhatsApp Green
        buttonText="Peça pelo WhatsApp"
        buttonIconSize="24"
        buttonBackgroundColor="#128C7E" // Darker WhatsApp Green
        buttonTextColor="#ffffff"
      />
    </main>
  );
}

